package Motorb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3MotorbApplicationTests {

	@Test
	void contextLoads() {
	}

}
